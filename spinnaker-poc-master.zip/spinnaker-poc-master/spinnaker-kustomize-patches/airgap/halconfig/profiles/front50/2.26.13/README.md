This directory contains skeleton Front50 configs to which Halyard concatenates
its generated deployment-specific config.

These configs are **deprecated** and in general should not be further updated. To
set a default config value, either set the value in `front50-web/config/front50.yml`
or set a default in the code reading the config property.
