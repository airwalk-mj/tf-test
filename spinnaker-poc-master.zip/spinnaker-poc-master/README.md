# spinnaker-poc

## Clone this repo to your local machine
$ git clone https://alm-github.systems.uk.hsbc/45106943/spinnaker-poc.git

# Download the BOM from GitHub (public copy)
$ cd spinnaker-poc/spinnaker-kustomize-patches/

$ ./airgap/bomdownloader.sh 2.26.3 725071346040.dkr.ecr.eu-west-1.amazonaws.com/scanned/stage/shp/tool-images/armory

## Upload the BOM to S3 (private copy)
$ cd spinnaker-poc/spinnaker-kustomize-patches/airgap/

$ aws s3 cp halconfig s3://380567612467-dev-spinnaker-front50-eu-west-2/halconfig --recursive --sse AES256 --region eu-west-2

# Download the Armory Operator Manifests
$ cd spinnaker-poc/spinnaker-kustomize-patches/

$ bash -c 'curl -L https://github.com/armory-io/spinnaker-operator/releases/latest/download/manifests.tgz | tar -xz'

## Update Armory Operator Manifests with a new Container repository address
$ cd spinnaker-poc/spinnaker-kustomize-patches/

$ ./airgap/operatorimageudpate.sh 725071346040.dkr.ecr.eu-west-1.amazonaws.com/scanned/stage/shp/tool-images/armory

# Update Halyard configuration to use our private BOM
$ vi spinnaker-kustomize-patches/operator/halyard-local.yml

        aws:
          enabled: true
          bucket: 380567612467-dev-spinnaker-front50-eu-west-2
          region: eu-west-2
          enablePathStyleAccess: false
          endpoint: s3://380567612467-dev-spinnaker-front50-eu-west-2/halconfig/
          anonymousAccess: false

# Deploy the Armory Operator
$ cd spinnaker-poc/spinnaker-kustomize-patches/operator/

$ kubectl apply -k .


